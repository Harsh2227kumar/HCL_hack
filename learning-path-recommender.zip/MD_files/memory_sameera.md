# Sameera's working memory — personal, not shared, gitignored
